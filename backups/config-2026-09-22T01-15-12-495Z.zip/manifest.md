# Backup de configuracao — 2026-09-22T01:15:12.495Z

- Git: commit `59696eb9d0010d0f7981a43b59c2912b90b00039` (tag `checkpoint-2026-09-21-agentic-safety`) — ATENCAO: working tree com mudancas nao commitadas
- Modo: **PRACTICE** · auto_execute: **true** · stake default: **2** · global max: **100**
- Seguranca (agentes): **50%** · niveis A/B: **100,90,80,70,50,50F,50FT,50FTS,50S,50T**
- Contadores zerados desde: **Mon Sep 21 2026 21:27:32 GMT-0300 (Horário Padrão de Brasília)**
- MCP oficial: **configurado (••••tHTB)**
- Entry window (agentic): **T-34s .. T-31,5s** · filtros do consenso: **constancia (sempre), CF/ST/S (variantes A/B)**
- Mercados ativos: (selection_json sem lista simples)

## Runs
- `agentic-blitz-45s` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Mon Sep 21 2026 20:41:16 GMT-0300 (Horário Padrão de Brasília)
- `agentic-rsi-fib-20260921` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Mon Sep 21 2026 08:06:16 GMT-0300 (Horário Padrão de Brasília)
- `s04-bollinger-50-20260921` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Mon Sep 21 2026 04:55:03 GMT-0300 (Horário Padrão de Brasília)
- `lab6-20260920-practice` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Sun Sep 20 2026 19:45:41 GMT-0300 (Horário Padrão de Brasília)

## Como restaurar
1. `git checkout <commit/tag>` e deploy (relay + vercel).
2. Aplicar `config.json`: `node scripts/restore-config.mjs <zip> --apply` (upsert das tabelas).
3. Reconfigurar envs (ver env-names.txt) no Railway e re-armar via painel (`ARM_PRACTICE`).

> Segredos NUNCA entram neste backup (token MCP, ssid, TOKEN_SIGNING_SECRET, senhas).
