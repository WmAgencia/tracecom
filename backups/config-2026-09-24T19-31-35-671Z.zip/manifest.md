# Backup de configuracao — 2026-09-24T19:31:35.671Z

- Git: commit `635e1d8ac2829d2ce890047736bf719df6d6f385` (tag `checkpoint-2026-09-21-agentic-safety`)
- Modo: **PRACTICE** · auto_execute: **true** · stake default: **2** · global max: **100**
- Seguranca (agentes): **5%** · niveis A/B: **50,50FT,50T,5FT,5FTC,5FTS,5FTSC,5S**
- Contadores zerados desde: **Tue Sep 22 2026 10:23:20 GMT-0300 (Horário Padrão de Brasília)**
- MCP oficial: **configurado (••••KM3y)**
- Entry window (agentic): **T-34s .. T-31,5s** · filtros do consenso: **constancia (sempre), CF/ST/S (variantes A/B)**
- Mercados ativos: (selection_json sem lista simples)

## Runs
- `s04-50-tests-a-1790122872387` — RUNNING · stake 2 · specs 90e21afaeb · iniciado Tue Sep 22 2026 21:21:15 GMT-0300 (Horário Padrão de Brasília)
- `agentic-tests-1790091128458` — RUNNING · stake 2 · specs agentic · iniciado Tue Sep 22 2026 12:32:09 GMT-0300 (Horário Padrão de Brasília)
- `agentic-blitz-45s` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Mon Sep 21 2026 20:41:16 GMT-0300 (Horário Padrão de Brasília)
- `agentic-rsi-fib-20260921` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Mon Sep 21 2026 08:06:16 GMT-0300 (Horário Padrão de Brasília)
- `s04-bollinger-50-20260921` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Mon Sep 21 2026 04:55:03 GMT-0300 (Horário Padrão de Brasília)
- `lab6-20260920-practice` — RUNNING · stake 1 · specs 90e21afaeb · iniciado Sun Sep 20 2026 19:45:41 GMT-0300 (Horário Padrão de Brasília)

## Como restaurar
1. `git checkout <commit/tag>` e deploy (relay + vercel).
2. Aplicar `config.json`: `node scripts/restore-config.mjs <zip> --apply` (upsert das tabelas).
3. Reconfigurar envs (ver env-names.txt) no Railway e re-armar via painel (`ARM_PRACTICE`).

> Segredos NUNCA entram neste backup (token MCP, ssid, TOKEN_SIGNING_SECRET, senhas).
